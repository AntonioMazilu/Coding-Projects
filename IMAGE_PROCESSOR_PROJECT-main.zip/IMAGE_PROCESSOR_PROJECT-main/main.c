// ----- 3o Project -----
// ------------------------------------------------------------------
// Sxoinoplokakhs Emmanouhl  (dit20204@go.uop.gr) - (2022202000204) |
// Ion Antonio Mazilou       (dit20131@go.uop.gr) - (2022202000131) |
// ------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header.h"
#include <dirent.h>

int main(int argsc, char *argsv[])
{

    int i, result = CheckArgs(argsc, argsv);
    
    
    if (result)
    {
        struct bmp_header *header[6];
        struct bmp_info *info[6];
        
        header[0] = Values(0, "test_images/airballoons1.bmp", header[0]);
        info[0] = Values2(0, "test_images/airballoons1.bmp", info[0]);
        header[1] = Values(1, "test_images/airballoons2.bmp", header[1]);
        info[1] = Values2(1, "test_images/airballoons2.bmp", info[1]);
        header[2] = Values(2, "test_images/books.bmp", header[2]);
        info[2] = Values2(2, "test_images/books.bmp", info[2]);
        header[3] = Values(3, "test_images/colors.bmp", header[3]);
        info[3] = Values2(3, "test_images/colors.bmp", info[3]);
        header[4] = Values(4, "test_images/lena.bmp", header[4]);
        info[4] = Values2(4, "test_images/lena.bmp", info[4]);
        header[5] = Values(5, "test_images/rainbow.bmp", header[5]);
        info[5] = Values2(5, "test_images/rainbow.bmp", info[5]);

        if (argsc > 3)
        {
            DIR *directory = opendir("output");
            if (directory == NULL)
            {
                system("mkdir output");
            }
        }

        switch (result)
        {
            case 1: // -a
            
                if (!strcmp(argsv[2], "airballoons1"))
                    OptionAFromCommandLine(argsv, header[0], info[0]);
                else if (!strcmp(argsv[2], "airballoons2"))
                    OptionAFromCommandLine(argsv, header[1], info[1]);
                else if (!strcmp(argsv[2], "books"))
                    OptionAFromCommandLine(argsv, header[2], info[2]);
                else if (!strcmp(argsv[2], "colors"))
                    OptionAFromCommandLine(argsv, header[3], info[3]);
                else if (!strcmp(argsv[2], "lena"))
                    OptionAFromCommandLine(argsv, header[4], info[4]);
                else if (!strcmp(argsv[2], "rainbow"))
                    OptionAFromCommandLine(argsv, header[5], info[5]);
                else
                    printf("Error! To arxeio auto den brethike.\n");

                break;
            case 2: // -fh
                
                InputOuputFromCommandLine(argsv);

                break;
            case 3: // fv

                InputOuputFromCommandLine(argsv);
                
                break;
            case 4: // -bw

                InputOuputFromCommandLine(argsv);
                
                break;
            default:
                printf("Error! H parametros auth gia to option den uparxei.\n");
                break;
        }

        for (i = 0; i < 6; i++)
        {
            if (header[i] != NULL)
                free(header[i]);
            if (info[i] != NULL)
                free(info[i]);
        }
    }
    else
        printf("Error! H parametros auth gia to option den uparxei.\n");
        

    return 0;
}