// ----- 3o Project -----
// ------------------------------------------------------------------
// Sxoinoplokakhs Emmanouhl  (dit20204@go.uop.gr) - (2022202000204) |
// Ion Antonio Mazilou       (dit20131@go.uop.gr) - (2022202000131) |
// ------------------------------------------------------------------

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "header.h"

void InputOuputFromCommandLine(char *argsv[])
{
    if (CheckInput(argsv))
    {    
        FileOutput(argsv);
    }
    // else
    // {
    //     printf("Error! To arxeio den brethike h den uparxei diathesimh mnhmh.\n");
    // }
}

int CheckArgs(int num, char *argsv[])
{
    if (num > 1) 
    {
        if (!strcmp(argsv[1], "-a"))
        {
            if (num == 2)
            {
                printf("Error! Me to option -a tha prepei na dwseis ena input ws trito orisma sto command line.\n");
                return 0;
            }
            else if (num > 3) 
            {
                printf("Error! Dwthikan parapanw parametroi sto option -a.\n");
                return 1;
            }
            // return 0 ? num == 2 || num > 3 : num == 3 && argsv[2] != NULL;
        }

        // if (num < 4 || num > 4)
        // {
        //     if (num < 4)
        //         printf("Error! Ta arguments einai mikrotera toy 4 sto command line.\n");
        //     else if (num > 4)
        //         printf("Error! Ta arguments einai megalutera toy 4 sto command line.\n");
        //     return 0 || 1 ? num < 4 : num > 4;
        // }

        if (num > 3 && !strcmp(argsv[1], "-fh"))
        {
            return 2;
        }
        
        if (num > 3 && !strcmp(argsv[1], "-fv"))
        {
            return 3;
        }
        
        int cmp = strcmp(argsv[1], "-bw");
        if (cmp && cmp == '_')
        {
            int sum = 0;
            char *token = strtok(argsv[1], "_");
            
            while (token != NULL)
            {
                sum++;
                // printf("token = %s\n", token);
                token = strtok(NULL, "_");
            }

            if (sum != 3)
                printf("Error! To option -bw tha prepei na exei 3 parametrous xwrismena me katw paula.\n");
            return (sum == 3) ? 4 : 0;
        }
    }

    return 0;
}

int CheckInput(char *argsv[])
{
    char *arr;
    arr = (char *) malloc(sizeof(char) * 12);

    if (arr != NULL)
    {
        strcpy(arr, "test_images/");

        arr = (char *) realloc(arr, sizeof(char) * strlen(argsv[2]));
        if (arr != NULL)
        {
            strcat(arr, argsv[2]);
            strcat(arr, ".bmp");

            FILE *ptr_file = fopen(arr, "r");

            if (ptr_file == NULL)
            {
                free(arr);
                return 0;
            }
            else
            {
                fclose(ptr_file);
                free(arr);
                return 500;
            }
        }
        else
        {
            printf("Error! Den uparxei diathesimh mnhmh.\n");
            free(arr);
            return 0;
        }
    }
    else
    {
        printf("Error! Den uparxei diathesimh mnhmh.\n");
        free(arr);
        return 0;
    }
}

void FileOutput(char *argsv[])
{
    char *ptr_out;

    ptr_out = (char *) malloc(sizeof(char) * 7);
    if (ptr_out != NULL)
    {
        strcpy(ptr_out, "output/");

        ptr_out = (char *) realloc(ptr_out, sizeof(char) * strlen(argsv[3]));
        if (ptr_out != NULL)
        {
            strcat(ptr_out, argsv[3]);
            strcat(ptr_out, ".bmp");
        }
    }

    FILE *ptr_file_out;
    ptr_file_out = fopen(ptr_out, "r+");
    
    if (ptr_file_out == NULL)
    {
        ptr_file_out = fopen(ptr_out, "w");
    
        fclose(ptr_file_out);
    }

    free(ptr_out);
}

void *Values(int i, char args[], struct bmp_header *header)
{
    FILE *file;
    file = fopen(args, "r");
    if (file != NULL)
    {
        header = (struct bmp_header *) malloc(sizeof(struct bmp_header));
        readHeader(file, header);
        return header;
    }

    return NULL;
}

void *Values2(int i, char args[], struct bmp_info *info)
{
    FILE *file;
    file = fopen(args, "r");
    if (file != NULL)
    {
        info = (struct bmp_info *) malloc(sizeof(struct bmp_info));
        readInfo(file, info);
        fclose(file);
        return info;
    }

    return NULL;
}

void OptionAFromCommandLine(char *argsv[], struct bmp_header *header, struct bmp_info *info)
{
    printf("Typwsh stoixeiwn gia thn eikona [%s.bmp]\n", argsv[2]);
    printf("--- bmp_header ---\n");
    printf("bfType = %d\n", header->bfType);
    printf("bfSize = %d\n", header->bfSize);
    printf("bfReserved1 = %d\n", header->bfReserved1);
    printf("bfReserved2 = %d\n", header->bfReserved2);
    printf("bfOffBits = %d\n", header->bfOffBits);
    printf("--- bmp_info ---\n");
    printf("biSize = %d\n", info->bmiHeader.biSize);
    printf("biWidth = %d\n", info->bmiHeader.biWidth);
    printf("biHeight = %d\n", info->bmiHeader.biHeight);
    printf("biPlanes = %d\n", info->bmiHeader.biPlanes);
    printf("biBitCount = %d\n", info->bmiHeader.biBitCount);
    printf("biCompression = %d\n", info->bmiHeader.biCompression);
    printf("biSizeImage = %d\n", info->bmiHeader.biSizeImage);
    printf("biXPelsPerMeter = %d\n", info->bmiHeader.biXPelsPerMeter);
    printf("biYPelsPerMeter = %d\n", info->bmiHeader.biYPelsPerMeter);
    printf("biClrUsed = %d\n", info->bmiHeader.biClrUsed);
    printf("biClrImportant = %d\n", info->bmiHeader.biClrImportant);
}

// 2: -fh
// 3: -fv
// 4: -bw
// 5: -p