<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>db1u01 Website</title>
        <link rel="stylesheet" href="../style.css">

    </head>

    <body>

    <div class="navbar">
            <nav>
                <ul>
                    <li> <a class="active" href="http://hilon.dit.uop.gr/~db1u01/">Αρχική</a></li>

                    <li id = "menu"> <a href="#">Εισαγωγή Στοιχείου</a>
                        <ul id = "sub_menu">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu2"> <a href="#">Διαγραφή Στοιχείου</a>
                        <ul id = "sub_menu2">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deleteusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deletesensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu3"> <a href="#">Εμφάνιση Στοιχείων</a>
                        <ul id = "sub_menu3">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu4"> <a href="#">Εισαγωγή Αρχείου</a>
                        <ul id = "sub_menu4">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/addallfiles.php">allfiles</a></li>
                        </ul>
                    </li>
                    <li id = "menu5"> <a href="#">Διαγραφή και Επαναφορά Πίνακα</a>
                        <ul id = "sub_menu5">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetall.php">reset all</a></li>
                        </ul>
                    </li>
                    <li id = "menu6"> <a href="#">Ερωτήματα 3ου Παραδοτέου</a>
                        <ul id = "sub_menu6">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q1.php">Ερώτημα 1</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q2.php">Ερώτημα 2</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q3.php">Ερώτημα 3</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q4.php">Ερώτημα 4</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q5.php">Ερώτημα 5</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q6.php">Ερώτημα 6</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q7.php">Ερώτημα 7</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q8.php">Ερώτημα 8</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q9.php">Ερώτημα 9</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q10.php">Ερώτημα 10</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q11.php">Ερώτημα 11</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q12.php">Ερώτημα 12</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q13.php">Ερώτημα 13</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>

        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <br>
            <label for="sensor">Επιλέξτε Αισθητήρα για Εμφάνιση:</label>
            <br>
            <select name="sensor" id="sensor">
                <option value="geolocationsensor">Αισθητήρας Τοποθεσίας</option>
                <option value="accerelationsensor">Επιταχυνσιόμετρο</option>
                <option value="magnetometersensor">Μαγνητόμετρο</option>
                <option value="gyroscopesensor">Γυροσκόπιο</option>
                <option value="barometersensor">Βαρόμετρο</option>
                <option value="proximitysensor">Αισθητήρας Εγγύτητας</option>
                <option value="pedometersensor">Βηματόμετρο</option>
            </select>
            <br>
            <br>
            <input type="submit" value="Yποβολή">
        </form>

    <?php
        echo '<br>';
        error_reporting(0);
        $db = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");

        if ($_SERVER["REQUEST_METHOD"] == "POST") {
            $sensor = $_POST['sensor'];
            $query = "SELECT * FROM " . $sensor . ";";
            $result = pg_query($db, $query);
    
            // Start the table
            echo '<table border="3">';
    
            // Add the headers based on sensor type
            echo '<tr>';
            switch ($sensor) {
                case 'geolocationsensor':
                    echo '<th>id</th><th>uid</th><th>timestamp</th><th>latitude</th><th>longitude</th><th>altitude</th>';
                    break;
                case 'accerelationsensor':
                    echo '<th>id</th><th>uid</th><th>timestamp</th><th>acceleration_x</th><th>acceleration_y</th><th>acceleration_z</th>';
                    break;
                case 'magnetometersensor':
                    echo '<th>id</th><th>uid</th><th>timestamp</th><th>magnetometer_x</th><th>magnetometer_y</th><th>magnetometer_z</th>';
                    break;
                case 'gyroscopesensor':
                    echo '<th>id</th><th>uid</th><th>timestamp</th><th>gyroscope_x</th><th>gyroscope_y</th><th>gyroscope_z</th>';
                    break;
                case 'barometersensor':
                    echo '<th>id</th><th>uid</th><th>timestamp</th><th>pressure</th>';
                    break;
                case 'proximitysensor':
                    echo '<th>id</th><th>uid</th><th>timestamp</th><th>proximity</th>';
                    break;
                case 'pedometersensor':
                    echo '<th>id</th><th>uid</th><th>timestamp</th><th>steps</th>';
                    break;
                default:
                    // Handle any other sensor type or provide a default set of headers
                    break;
            }
            echo '</tr>';
    
            // Fetch and display the rows
            while ($row = pg_fetch_array($result)) {
                echo '<tr>';
                // Display data based on sensor type
                switch ($sensor) {
                    case 'geolocationsensor':
                        echo "<td>{$row['id']}</td><td>{$row['uid']}</td><td>{$row['timestamp']}</td><td>{$row['latitude']}</td><td>{$row['longitude']}</td><td>{$row['altitude']}</td>";
                        break;
                    case 'accerelationsensor':
                        echo "<td>{$row['id']}</td><td>{$row['uid']}</td><td>{$row['timestamp']}</td><td>{$row['acceleration_x']}</td><td>{$row['acceleration_y']}</td><td>{$row['acceleration_z']}</td>";
                        break;
                    case 'magnetometersensor':
                        echo "<td>{$row['id']}</td><td>{$row['uid']}</td><td>{$row['timestamp']}</td><td>{$row['magnetometer_x']}</td><td>{$row['magnetometer_y']}</td><td>{$row['magnetometer_z']}</td>";
                        break;
                    case 'gyroscopesensor':
                        echo "<td>{$row['id']}</td><td>{$row['uid']}</td><td>{$row['timestamp']}</td><td>{$row['gyroscope_x']}</td><td>{$row['gyroscope_y']}</td><td>{$row['gyroscope_z']}</td>";
                        break;
                    case 'barometersensor':
                        echo "<td>{$row['id']}</td><td>{$row['uid']}</td><td>{$row['timestamp']}</td><td>{$row['pressure']}</td>";
                        break;
                    case 'proximitysensor':
                        echo "<td>{$row['id']}</td><td>{$row['uid']}</td><td>{$row['timestamp']}</td><td>{$row['proximity']}</td>";
                        break;
                    case 'pedometersensor':
                        echo "<td>{$row['id']}</td><td>{$row['uid']}</td><td>{$row['timestamp']}</td><td>{$row['steps']}</td>";
                        break;
                    default:
                        // Handle any other sensor type or provide a default set of data display
                        break;
                }
                echo '</tr>';
            }
            echo '</table>';
        }
    
        // Close the database connection
        pg_close($db);
        
    ?>
</body>
    <?php
        clearstatcache();
    ?>
</html>