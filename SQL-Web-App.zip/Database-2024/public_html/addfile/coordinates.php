<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>db1u01 Website</title>
        <link rel="stylesheet" href="../style.css">

    </head>

    <body>

    <div class="navbar">
            <nav>
                <ul>
                    <li> <a class="active" href="http://hilon.dit.uop.gr/~db1u01/">Αρχική</a></li>

                    <li id = "menu"> <a href="#">Εισαγωγή Στοιχείου</a>
                        <ul id = "sub_menu">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu2"> <a href="#">Διαγραφή Στοιχείου</a>
                        <ul id = "sub_menu2">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deleteusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deletesensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu3"> <a href="#">Εμφάνιση Στοιχείων</a>
                        <ul id = "sub_menu3">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showsensors.php">Αισθητηρων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showcoordinates.php">Συντεταγμενων</a></li>
                        </ul>
                    </li>
                    <li id = "menu4"> <a href="#">Εισαγωγή Αρχείου</a>
                        <ul id = "sub_menu4">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/users.php">users.csv</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/sensors.php">sensorsF.csv</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/coordinates.php">coordinatesF.csv</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/addallfiles.php">allfiles</a></li>
                        </ul>
                    </li>
                    <li id = "menu5"> <a href="#">Διαγραφή και Επαναφορά Πίνακα</a>
                        <ul id = "sub_menu5">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetusers.php">reset Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetsensors.php">reset Αισθητηρων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetcoordinates.php">reset Συντεταγμενων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetall.php">reset all</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>

        <?php
            $conn = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");

            // Create the table
            $query = "CREATE TABLE IF NOT EXISTS coordinatesf_tmp (
                uid VARCHAR(255),
                timestamp BIGINT,
                latitude FLOAT,
                longitude FLOAT,
                altitude FLOAT
            );";

            $result = pg_query($conn, $query);

            if (!$result) {
                echo "An error occurred while creating the table.\n";
                exit;
            }

            exec('./coordinates.sh', $output, $return) or die("Error executing exec command!!!");
            
            echo '<br>';
            echo '<br>';

            if ($return === 0) 
            {
                echo "Command was successfully executed!";
            } 
            else 
            {
                echo "Command failed with return code " . $return;
            }


            $result = pg_query($conn, "INSERT INTO geolocationsensor (uid, timestamp, latitude, longitude, altitude)
            SELECT uid, timestamp, latitude, longitude, altitude FROM coordinatesf_tmp;");

            if (!$result) {
                echo "An error occurred while inserting the table.\n";
                exit;
            }

            //Drop the table
            $result = pg_query($conn, "drop table coordinatesf_tmp;");

            if (!$result) {
                echo "An error occurred while dropping the table.\n";
                exit;
            }
            pg_close($conn);
            ?> 
    
        </body>
    
        <?php
            clearstatcache();
        ?>
    
    </html>