<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>db1u01 Website</title>
        <link rel="stylesheet" href="../style.css">

    </head>

    <body>

    <div class="navbar">
            <nav>
                <ul>
                    <li> <a class="active" href="http://hilon.dit.uop.gr/~db1u01/">Αρχική</a></li>

                    <li id = "menu"> <a href="#">Εισαγωγή Στοιχείου</a>
                        <ul id = "sub_menu">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu2"> <a href="#">Διαγραφή Στοιχείου</a>
                        <ul id = "sub_menu2">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deleteusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deletesensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu3"> <a href="#">Εμφάνιση Στοιχείων</a>
                        <ul id = "sub_menu3">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu4"> <a href="#">Εισαγωγή Αρχείου</a>
                        <ul id = "sub_menu4">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/addallfiles.php">allfiles</a></li>
                        </ul>
                    </li>
                    <li id = "menu5"> <a href="#">Διαγραφή και Επαναφορά Πίνακα</a>
                        <ul id = "sub_menu5">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetall.php">reset all</a></li>
                        </ul>
                    </li>
                    <li id = "menu6"> <a href="#">Ερωτήματα 3ου Παραδοτέου</a>
                        <ul id = "sub_menu6">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q1.php">Ερώτημα 1</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q2.php">Ερώτημα 2</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q3.php">Ερώτημα 3</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q4.php">Ερώτημα 4</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q5.php">Ερώτημα 5</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q6.php">Ερώτημα 6</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q7.php">Ερώτημα 7</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q8.php">Ερώτημα 8</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q9.php">Ερώτημα 9</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q10.php">Ερώτημα 10</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q11.php">Ερώτημα 11</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q12.php">Ερώτημα 12</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q13.php">Ερώτημα 13</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>

        <?php
            $conn = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");

            
            $query = "CREATE TABLE IF NOT EXISTS users_tmp (
                uid VARCHAR(255),
                email VARCHAR(255),
                username VARCHAR(255),
                password VARCHAR(255),
                surname VARCHAR(255),
                name VARCHAR(255)
            );";

            $result = pg_query($conn, $query);

            if (!$result) 
            {
                echo "An error occurred while creating the table users_tmp.\n";
                exit;
            }
            else
            {
                echo "Table users_tmp created succesfully!\n";
            }

            exec('./users.sh', $output, $return) or die("Error executing exec command!!!");
            
            echo '<br>';
            echo '<br>';

            if ($return === 0) 
            {
                echo "Command was successfully executed!";
            } 
            else 
            {
                echo "Command failed with return code " . $return;
            }        

            $query = "CREATE TABLE IF NOT EXISTS coordinatesf_tmp (
                uid VARCHAR(255),
                timestamp BIGINT,
                latitude FLOAT,
                longitude FLOAT,
                altitude FLOAT
            );";

            $result = pg_query($conn, $query);

            if (!$result) 
            {
                echo "An error occurred while creating the table coordinatesf_tmp.\n";
                exit;
            }
            else
            {
                echo "Table coordinatesf_tmp created succesfully!\n";
            }

            exec('./coordinates.sh', $output, $return) or die("Error executing exec command!!!");
            
            echo '<br>';
            echo '<br>';

            if ($return === 0) 
            {
                echo "Command was successfully executed!";
            } 
            else 
            {
                echo "Command failed with return code " . $return;
            }
            
            // Create the table
            $query = "CREATE TABLE IF NOT EXISTS sensorsf_tmp (
                uid VARCHAR(255),
                timestamp BIGINT,
                pressure FLOAT,
                acceleration_x FLOAT,
                acceleration_y FLOAT,
                acceleration_z FLOAT,
                gyroscope_x FLOAT,
                gyroscope_y FLOAT,
                gyroscope_z FLOAT,
                magnetometer_x FLOAT,
                magnetometer_y FLOAT,
                magnetometer_z FLOAT,
                proximity BOOLEAN,
                steps INT
            );";

            $result = pg_query($conn, $query);

            if (!$result) 
            {
                echo "An error occurred while creating the table sensorsf_tmp.\n";
                exit;
            }
            else
            {
                echo "Table sensorsf_tmp created succesfully!\n";
            }

            exec('./sensors.sh', $output, $return) or die("Error executing exec command!!!");
            
            echo '<br>';
            echo '<br>';

            if ($return === 0) 
            {
                echo "Command was successfully executed!";
            } 
            else 
            {
                echo "Command failed with return code " . $return;
            }

            //------------------------------------------------------------------------------------------

            $result = pg_query($conn, "INSERT INTO users (uid, email, username, password, surname, name)
            SELECT uid, email, username, password, surname, name FROM users_tmp;");

            if (!$result) 
            {
                echo "An error occurred while inserting into the table users.\n";
                exit;
            }
            else
            {
                echo "Inserting into the table users was successful!\n";
            }

            $result = pg_query($conn, "INSERT INTO geolocationsensor (uid, timestamp, latitude, longitude, altitude)
            SELECT uid, timestamp, latitude, longitude, altitude FROM coordinatesf_tmp;");

            if (!$result) 
            {
                echo "An error occurred while inserting into the table geolocationsensor.\n";
                exit;
            }
            else
            {
                echo "Inserting into the table geolocationsensor was successful!\n";
            }

            $result = pg_query($conn, "INSERT INTO accelerationsensor (uid, timestamp, acceleration_x, acceleration_y, acceleration_z)
            SELECT uid, timestamp, acceleration_x, acceleration_y, acceleration_z FROM sensorsf_tmp;");

            if (!$result) 
            {
                echo "An error occurred while inserting into the table accelerationsensor.\n";
                exit;
            }
            else
            {
                echo "Inserting into the table accelerationsensor was successful!\n";
            }

            $result = pg_query($conn, "INSERT INTO magnetometersensor (uid, timestamp, magnetometer_x, magnetometer_y, magnetometer_z)
            SELECT uid, timestamp, magnetometer_x, magnetometer_y, magnetometer_z FROM sensorsf_tmp;");

            if (!$result) {
                echo "An error occurred while inserting the table.\n";
                exit;
            }

            $result = pg_query($conn, "INSERT INTO gyroscopesensor (uid, timestamp, gyroscope_x, gyroscope_y, gyroscope_z)
            SELECT uid, timestamp, gyroscope_x, gyroscope_y, gyroscope_z FROM sensorsf_tmp;");

            if (!$result) 
            {
                echo "An error occurred while inserting into the table gyroscopesensor.\n";
                exit;
            }
            else
            {
                echo "Inserting into the table gyroscopesensor was successful!\n";
            }

            $result = pg_query($conn, "INSERT INTO barometersensor (uid, timestamp, pressure)
            SELECT uid, timestamp, pressure FROM sensorsf_tmp;");

            if (!$result) 
            {
                echo "An error occurred while inserting into the table barometersensor.\n";
                exit;
            }
            else
            {
                echo "Inserting into the table barometersensor was successful!\n";
            }

            $result = pg_query($conn, "INSERT INTO proximitysensor (uid, timestamp, proximity)
            SELECT uid, timestamp, proximity FROM sensorsf_tmp;");

            if (!$result) 
            {
                echo "An error occurred while inserting into the table proximitysensor.\n";
                exit;
            }
            else
            {
                echo "Inserting into the table proximitysensor was successful!\n";
            }

            $result = pg_query($conn, "INSERT INTO pedometersensor (uid, timestamp, steps)
            SELECT uid, timestamp, steps FROM sensorsf_tmp;");

            if (!$result) 
            {
                echo "An error occurred while inserting into the table pedometersensor.\n";
                exit;
            }
            else
            {
                echo "Inserting into the table pedometersensor was successful!\n";
            }

            //------------------------------------------------------------------------------------------

            // Drop the table
            $query = "drop table users_tmp,coordinatesf_tmp,sensorsf_tmp;";   

            $result = pg_query($conn, $query);
    
            if (!$result) {
                echo "An error occurred while dropping the temp tables.\n";
                exit;
            }
            else
            {
                echo "Temp tables deleted succesfully!\n";
            }
            
            pg_close($conn);
        ?> 

    </body>

    <?php
        clearstatcache();
    ?>

</html>