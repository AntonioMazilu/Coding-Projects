export PGPASSWORD=kvdKXMKF

psql -h localhost -U db1u01 db1u01 < users.txt