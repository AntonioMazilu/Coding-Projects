<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>db1u01 Website</title>
        <link rel="stylesheet" href="../style.css">

    </head>

    <body>

    <div class="navbar">
            <nav>
                <ul>
                    <li> <a class="active" href="http://hilon.dit.uop.gr/~db1u01/">Αρχική</a></li>

                    <li id = "menu"> <a href="#">Εισαγωγή Στοιχείου</a>
                        <ul id = "sub_menu">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu2"> <a href="#">Διαγραφή Στοιχείου</a>
                        <ul id = "sub_menu2">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deleteusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deletesensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu3"> <a href="#">Εμφάνιση Στοιχείων</a>
                        <ul id = "sub_menu3">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu4"> <a href="#">Εισαγωγή Αρχείου</a>
                        <ul id = "sub_menu4">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/addallfiles.php">allfiles</a></li>
                        </ul>
                    </li>
                    <li id = "menu5"> <a href="#">Διαγραφή και Επαναφορά Πίνακα</a>
                        <ul id = "sub_menu5">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetall.php">reset all</a></li>
                        </ul>
                    </li>
                    <li id = "menu6"> <a href="#">Ερωτήματα 3ου Παραδοτέου</a>
                        <ul id = "sub_menu6">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q1.php">Ερώτημα 1</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q2.php">Ερώτημα 2</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q3.php">Ερώτημα 3</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q4.php">Ερώτημα 4</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q5.php">Ερώτημα 5</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q6.php">Ερώτημα 6</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q7.php">Ερώτημα 7</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q8.php">Ερώτημα 8</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q9.php">Ερώτημα 9</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q10.php">Ερώτημα 10</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q11.php">Ερώτημα 11</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q12.php">Ερώτημα 12</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q13.php">Ερώτημα 13</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>

        <?php
            error_reporting(0);
            $db = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");

            // Get users and their accelerations
            $query = "SELECT DISTINCT users.id,
            users.username,
            SQRT(accelerationsensor.acceleration_x^2 + accelerationsensor.acceleration_y^2 + accelerationsensor.acceleration_z^2) AS avg_acceleration
            FROM users, accelerationsensor
            WHERE users.uid = accelerationsensor.uid
            ORDER BY avg_acceleration DESC;";

            $result = pg_query($db, $query);

            echo '<table border="3">';
            echo '<tr>';
            echo '<th>id</th>';
            echo '<th>Username</th>';
            echo '<th>Average Acceleration</th>';
            echo '</tr>';

            while ($row = pg_fetch_array($result)) {
                $id = $row['id'];
                $username = $row['username'];
                $avgAcceleration = $row['avg_acceleration'];

                echo '<tr>';
                echo "<td>$id</td>";
                echo "<td>$username</td>";
                echo "<td>$avgAcceleration</td>";
                echo '</tr>';
            }
            echo '</table>';
            pg_close($db);
        ?>


</body>

    <?php
        clearstatcache();
    ?>

</html>