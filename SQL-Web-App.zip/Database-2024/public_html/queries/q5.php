<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>db1u01 Website</title>
        <link rel="stylesheet" href="../style.css">

    </head>

    <body>

    <div class="navbar">
            <nav>
                <ul>
                    <li> <a class="active" href="http://hilon.dit.uop.gr/~db1u01/">Αρχική</a></li>

                    <li id = "menu"> <a href="#">Εισαγωγή Στοιχείου</a>
                        <ul id = "sub_menu">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu2"> <a href="#">Διαγραφή Στοιχείου</a>
                        <ul id = "sub_menu2">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deleteusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deletesensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu3"> <a href="#">Εμφάνιση Στοιχείων</a>
                        <ul id = "sub_menu3">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu4"> <a href="#">Εισαγωγή Αρχείου</a>
                        <ul id = "sub_menu4">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/addallfiles.php">allfiles</a></li>
                        </ul>
                    </li>
                    <li id = "menu5"> <a href="#">Διαγραφή και Επαναφορά Πίνακα</a>
                        <ul id = "sub_menu5">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetall.php">reset all</a></li>
                        </ul>
                    </li>
                    <li id = "menu6"> <a href="#">Ερωτήματα 3ου Παραδοτέου</a>
                        <ul id = "sub_menu6">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q1.php">Ερώτημα 1</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q2.php">Ερώτημα 2</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q3.php">Ερώτημα 3</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q4.php">Ερώτημα 4</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q5.php">Ερώτημα 5</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q6.php">Ερώτημα 6</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q7.php">Ερώτημα 7</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q8.php">Ερώτημα 8</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q9.php">Ερώτημα 9</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q10.php">Ερώτημα 10</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q11.php">Ερώτημα 11</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q12.php">Ερώτημα 12</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q13.php">Ερώτημα 13</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
        <h3><u>Εισαγωγή Υψόμετρου</u></h3>

        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <br>
            <label for="min_altitude">Ελάχιστο Υψόμετρο (Y):</label>
            <input type="number" step="0.01" name="min_altitude" id="min_altitude" required>
            <br>
            <label for="max_altitude">Μέγιστο Υψόμετρο (X):</label>
            <input type="number" step="0.01" name="max_altitude" id="max_altitude" required>
            <br><br>
            <input type="submit" value="Δείξε χρήστες" name="altitude_submit">
            <br>
        </form>

        <?php
            error_reporting(0);
            $db = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");

            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['altitude_submit'])) {
                $min_altitude = $_POST['min_altitude'];
                $max_altitude = $_POST['max_altitude'];

                // Display the specified altitudes
                echo "<h2>Ελάχιστο ύψος (Y): " . htmlspecialchars($min_altitude) . " - Μέγιστο ύψος (X): " . htmlspecialchars($max_altitude) . "</h2>";

                // Query to find users who have been above max_altitude but never below min_altitude
                $query = "SELECT 
                u.username,
                MAX(CASE WHEN g.altitude > $2 THEN g.altitude ELSE NULL END) AS max_altitude,
                MIN(CASE WHEN g.altitude > $2 THEN g.altitude ELSE NULL END) AS min_altitude
            FROM 
                users u, 
                geolocationsensor g
            WHERE 
                u.uid = g.uid
            GROUP BY 
                u.username
            HAVING 
                COUNT(CASE WHEN g.altitude < $1 THEN 1 ELSE NULL END) = 0
                AND MAX(g.altitude) > $2;";

                $result = pg_query_params($db, $query, array($min_altitude, $max_altitude));

                if ($result) {
                    echo "<table border='1'>";
                    echo "<tr><th>Username</th><th>Max Altitude</th><th>Min Altitude</th></tr>";

                    while ($row = pg_fetch_assoc($result)) {
                        echo "<tr><td>" . htmlspecialchars($row['username']) . "</td><td>" . htmlspecialchars($row['max_altitude']) . "</td><td>" . htmlspecialchars($row['min_altitude']) . "</td></tr>";
                    }

                    echo "</table>";
                } else {
                    echo "No matching users found.";
                }
            }
        ?>

</body>

    <?php
        clearstatcache();
    ?>

</html>