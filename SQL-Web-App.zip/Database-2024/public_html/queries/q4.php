<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>db1u01 Website</title>
        <link rel="stylesheet" href="../style.css">

    </head>

    <body>

    <div class="navbar">
            <nav>
                <ul>
                    <li> <a class="active" href="http://hilon.dit.uop.gr/~db1u01/">Αρχική</a></li>

                    <li id = "menu"> <a href="#">Εισαγωγή Στοιχείου</a>
                        <ul id = "sub_menu">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu2"> <a href="#">Διαγραφή Στοιχείου</a>
                        <ul id = "sub_menu2">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deleteusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deletesensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu3"> <a href="#">Εμφάνιση Στοιχείων</a>
                        <ul id = "sub_menu3">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu4"> <a href="#">Εισαγωγή Αρχείου</a>
                        <ul id = "sub_menu4">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/addallfiles.php">allfiles</a></li>
                        </ul>
                    </li>
                    <li id = "menu5"> <a href="#">Διαγραφή και Επαναφορά Πίνακα</a>
                        <ul id = "sub_menu5">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetall.php">reset all</a></li>
                        </ul>
                    </li>
                    <li id = "menu6"> <a href="#">Ερωτήματα 3ου Παραδοτέου</a>
                        <ul id = "sub_menu6">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q1.php">Ερώτημα 1</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q2.php">Ερώτημα 2</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q3.php">Ερώτημα 3</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q4.php">Ερώτημα 4</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q5.php">Ερώτημα 5</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q6.php">Ερώτημα 6</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q7.php">Ερώτημα 7</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q8.php">Ερώτημα 8</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q9.php">Ερώτημα 9</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q10.php">Ερώτημα 10</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q11.php">Ερώτημα 11</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q12.php">Ερώτημα 12</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q13.php">Ερώτημα 13</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
        <h3><u>Εισαγωγή Υψόμετρου</u></h3>

        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="post">
            <br>
            <label for="altitude">Ελάχιστο Υψόμετρο (Y):</label>
            <input type="number" step="0.01" name="altitude" id="altitude" required>
            <br>
            <br>
            <input type="submit" value="Δείξε χρήστες" name="altitude_submit">
            <br>
        </form>

        <?php
            error_reporting(0);
            $db = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");

            if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['altitude_submit'])) {
                $min_altitude = $_POST['altitude'];

                // Display minimum altitude
                echo "<h2>Ελάχιστο ύψος (Y): " . htmlspecialchars($min_altitude) . "</h2>";

                // Query to get user IDs with altitude above the specified value
                $userIdsQuery = "SELECT DISTINCT uid FROM geolocationsensor WHERE altitude > $1";
                $userIdsResult = pg_query_params($db, $userIdsQuery, array($min_altitude));

                if ($userIdsResult) {
                    $userIds = [];
                    while ($row = pg_fetch_assoc($userIdsResult)) {
                        $userIds[] = $row['uid'];
                    }

                    if (count($userIds) > 0) {
                        echo "<table border='1'>";
                        echo "<tr><th>Επίθετο</th><th>Όνομα</th><th>Max Altitude</th></tr>";

                        foreach ($userIds as $userId) {
                            // Query to get user details and their maximum altitude
                            $userDetailQuery = "SELECT users.surname, users.name, MAX(geolocationsensor.altitude) as max_altitude 
                                                FROM users, geolocationsensor
                                                WHERE users.uid = $1 AND geolocationsensor.uid = users.uid 
                                                GROUP BY users.surname, users.name
                                                ORDER BY users.surname";
                            $userDetailResult = pg_query_params($db, $userDetailQuery, array($userId));

                            if ($userDetail = pg_fetch_assoc($userDetailResult)) {
                                echo "<tr><td>" . htmlspecialchars($userDetail['surname']) . "</td><td>" . htmlspecialchars($userDetail['name']) . "</td><td>" . htmlspecialchars($userDetail['max_altitude']) . "</td></tr>";
                            }
                        }

                        echo "</table>";
                    } else {
                        echo "No users found with altitude greater than " . htmlspecialchars($min_altitude);
                    }
                } else {
                    echo "Error fetching user IDs.";
                }
            }
        ?>

</body>

    <?php
        clearstatcache();
    ?>

</html>