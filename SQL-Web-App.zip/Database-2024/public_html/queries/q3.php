<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>db1u01 Website</title>
        <link rel="stylesheet" href="../style.css">

    </head>

    <body>

    <div class="navbar">
            <nav>
                <ul>
                    <li> <a class="active" href="http://hilon.dit.uop.gr/~db1u01/">Αρχική</a></li>

                    <li id = "menu"> <a href="#">Εισαγωγή Στοιχείου</a>
                        <ul id = "sub_menu">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu2"> <a href="#">Διαγραφή Στοιχείου</a>
                        <ul id = "sub_menu2">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deleteusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deletesensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu3"> <a href="#">Εμφάνιση Στοιχείων</a>
                        <ul id = "sub_menu3">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu4"> <a href="#">Εισαγωγή Αρχείου</a>
                        <ul id = "sub_menu4">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/addallfiles.php">allfiles</a></li>
                        </ul>
                    </li>
                    <li id = "menu5"> <a href="#">Διαγραφή και Επαναφορά Πίνακα</a>
                        <ul id = "sub_menu5">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetall.php">reset all</a></li>
                        </ul>
                    </li>
                    <li id = "menu6"> <a href="#">Ερωτήματα 3ου Παραδοτέου</a>
                        <ul id = "sub_menu6">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q1.php">Ερώτημα 1</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q2.php">Ερώτημα 2</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q3.php">Ερώτημα 3</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q4.php">Ερώτημα 4</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q5.php">Ερώτημα 5</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q6.php">Ερώτημα 6</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q7.php">Ερώτημα 7</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q8.php">Ερώτημα 8</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q9.php">Ερώτημα 9</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q10.php">Ερώτημα 10</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q11.php">Ερώτημα 11</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q12.php">Ερώτημα 12</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q13.php">Ερώτημα 13</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>

        <?php
            error_reporting(0);
            $db = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");

            // Ερώτημα για τους χρήστες
            $queryUsers = "SELECT * FROM users ORDER BY username;";
            $resultUsers = pg_query($db, $queryUsers);

            // Ερωτήματα για στατιστικά δεδομένα
            $queryPressureCounts = "SELECT uid, COUNT(*) AS pressure_measurements_count FROM barometersensor GROUP BY uid;";
            $queryMinPressure = "SELECT uid, MIN(pressure) AS min_pressure FROM barometersensor GROUP BY uid;";
            $queryMaxPressure = "SELECT uid, MAX(pressure) AS max_pressure FROM barometersensor GROUP BY uid;";

            $resultPressureCounts = pg_query($db, $queryPressureCounts);
            $resultMinPressure = pg_query($db, $queryMinPressure);
            $resultMaxPressure = pg_query($db, $queryMaxPressure);

            // Συγκέντρωση στατιστικών δεδομένων σε πίνακες
            $pressureCounts = [];
            while ($row = pg_fetch_assoc($resultPressureCounts)) {
                $pressureCounts[$row['uid']] = $row['pressure_measurements_count'];
            }

            $minPressures = [];
            while ($row = pg_fetch_assoc($resultMinPressure)) {
                $minPressures[$row['uid']] = $row['min_pressure'];
            }

            $maxPressures = [];
            while ($row = pg_fetch_assoc($resultMaxPressure)) {
                $maxPressures[$row['uid']] = $row['max_pressure'];
            }

            // Εμφάνιση των δεδομένων
            echo '<table border="3">';
            echo '<tr>';
            echo '<th>Username</th>';
            echo '<th>Pressure Measurements</th>';
            echo '<th>Min Pressure</th>';
            echo '<th>Max Pressure</th>';
            echo '</tr>';

            while ($row = pg_fetch_array($resultUsers)) {
                $uid = $row['uid'];
                $username = $row['username'];

                $pressureCount = $pressureCounts[$uid] ?? 'N/A';
                $minPressure = $minPressures[$uid] ?? 'N/A';
                $maxPressure = $maxPressures[$uid] ?? 'N/A';

                echo '<tr>';
                echo "<td>$username</td>";
                echo "<td>$pressureCount</td>";
                echo "<td>$minPressure</td>";
                echo "<td>$maxPressure</td>";
                echo '</tr>';
            }

            echo '</table>';
            pg_close($db);
        ?>



</body>

    <?php
        clearstatcache();
    ?>

</html>