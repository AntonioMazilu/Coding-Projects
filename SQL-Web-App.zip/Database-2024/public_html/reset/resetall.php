<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>db1u01 Website</title>
        <link rel="stylesheet" href="../style.css">

    </head>

    <body>

    <div class="navbar">
            <nav>
                <ul>
                    <li> <a class="active" href="http://hilon.dit.uop.gr/~db1u01/">Αρχική</a></li>

                    <li id = "menu"> <a href="#">Εισαγωγή Στοιχείου</a>
                        <ul id = "sub_menu">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu2"> <a href="#">Διαγραφή Στοιχείου</a>
                        <ul id = "sub_menu2">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deleteusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deletesensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu3"> <a href="#">Εμφάνιση Στοιχείων</a>
                        <ul id = "sub_menu3">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu4"> <a href="#">Εισαγωγή Αρχείου</a>
                        <ul id = "sub_menu4">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/addallfiles.php">allfiles</a></li>
                        </ul>
                    </li>
                    <li id = "menu5"> <a href="#">Διαγραφή και Επαναφορά Πίνακα</a>
                        <ul id = "sub_menu5">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetall.php">reset all</a></li>
                        </ul>
                    </li>
                    <li id = "menu6"> <a href="#">Ερωτήματα 3ου Παραδοτέου</a>
                        <ul id = "sub_menu6">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q1.php">Ερώτημα 1</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q2.php">Ερώτημα 2</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q3.php">Ερώτημα 3</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q4.php">Ερώτημα 4</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q5.php">Ερώτημα 5</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q6.php">Ερώτημα 6</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q7.php">Ερώτημα 7</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q8.php">Ερώτημα 8</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q9.php">Ερώτημα 9</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q10.php">Ερώτημα 10</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q11.php">Ερώτημα 11</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q12.php">Ερώτημα 12</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q13.php">Ερώτημα 13</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>

    <?php
        $conn = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");

        //--------------------------------------------------------------------------------------------------------------
        $query = "drop table users, geolocationsensor, accelerationsensor, magnetometersensor, gyroscopesensor, barometersensor, proximitysensor, pedometersensor  CASCADE;";   

        $result = pg_query($conn, $query);

        if (!$result) {
            echo "An error occurred while dropping the tables.\n";
            exit;
        }
        else
        {
            echo "Tables droped succesfully!\n";
        }

        //--------------------------------------------------------------------------------------------------------------
        $query = "CREATE TABLE IF NOT EXISTS users (
            id SERIAL PRIMARY KEY,
            uid VARCHAR(255) UNIQUE,
            email VARCHAR(255),
            username VARCHAR(255),
            password VARCHAR(255),
            surname VARCHAR(255),
            name VARCHAR(255)
        );";

        $result = pg_query($conn, $query);

        if (!$result) {
            echo "An error occurred while creating the table users.\n";
            exit;
        }
        else
        {
            echo "Table users created succesfully!\n";
        }

        $query = "CREATE TABLE IF NOT EXISTS geolocationsensor (
            id SERIAL PRIMARY KEY,
            uid VARCHAR(255),
            timestamp BIGINT,
            longitude FLOAT,
            latitude FLOAT,
            altitude FLOAT,
            FOREIGN KEY (uid) REFERENCES users(uid)
        );";

        $result = pg_query($conn, $query);

        if (!$result) {
            echo "An error occurred while creating the table geolocationsensor.\n";
            exit;
        }
        else
        {
            echo "Table geolocationsensor created succesfully!\n";
        }

        $query = "CREATE TABLE IF NOT EXISTS accelerationsensor (
            id SERIAL PRIMARY KEY,
            uid VARCHAR(255),
            timestamp BIGINT,
            acceleration_x FLOAT,
            acceleration_y FLOAT,
            acceleration_z FLOAT,
            FOREIGN KEY (uid) REFERENCES users(uid)
        );";

        $result = pg_query($conn, $query);

        if (!$result) {
            echo "An error occurred while creating the table accelerationsensor.\n";
            exit;
        }
        else
        {
            echo "Table accelerationsensor created succesfully!\n";
        }

        $query = "CREATE TABLE IF NOT EXISTS magnetometersensor (
            id SERIAL PRIMARY KEY,
            uid VARCHAR(255),
            timestamp BIGINT,
            magnetometer_x FLOAT,
            magnetometer_y FLOAT,
            magnetometer_z FLOAT,
            FOREIGN KEY (uid) REFERENCES users(uid)
        );";

        $result = pg_query($conn, $query);

        if (!$result) {
            echo "An error occurred while creating the table magnetometersensor.\n";
            exit;
        }
        else
        {
            echo "Table magnetometersensor created succesfully!\n";
        }

        $query = "CREATE TABLE IF NOT EXISTS gyroscopesensor (
            id SERIAL PRIMARY KEY,
            uid VARCHAR(255),
            timestamp BIGINT,
            gyroscope_x FLOAT,
            gyroscope_y FLOAT,
            gyroscope_z FLOAT,
            FOREIGN KEY (uid) REFERENCES users(uid)
        );";

        $result = pg_query($conn, $query);

        if (!$result) {
            echo "An error occurred while creating the table gyroscopesensor.\n";
            exit;
        }
        else
        {
            echo "Table gyroscopesensor created succesfully!\n";
        }

        $query = "CREATE TABLE IF NOT EXISTS barometersensor (
            id SERIAL PRIMARY KEY,
            uid VARCHAR(255),
            timestamp BIGINT,
            pressure FLOAT,
            FOREIGN KEY (uid) REFERENCES users(uid)
        );";

        $result = pg_query($conn, $query);

        if (!$result) {
            echo "An error occurred while creating the table barometersensor.\n";
            exit;
        }
        else
        {
            echo "Table barometersensor created succesfully!\n";
        }

        $query = "CREATE TABLE IF NOT EXISTS proximitysensor (
            id SERIAL PRIMARY KEY,
            uid VARCHAR(255),
            timestamp BIGINT,
            proximity BOOLEAN,
            FOREIGN KEY (uid) REFERENCES users(uid)
        );";

        $result = pg_query($conn, $query);

        if (!$result) {
            echo "An error occurred while creating the table proximitysensor.\n";
            exit;
        }
        else
        {
            echo "Table proximitysensor created succesfully!\n";
        }

        $query = "CREATE TABLE IF NOT EXISTS pedometersensor (
            id SERIAL PRIMARY KEY,
            uid VARCHAR(255),
            timestamp BIGINT,
            steps INT,
            FOREIGN KEY (uid) REFERENCES users(uid)
        );";

        $result = pg_query($conn, $query);

        if (!$result) {
            echo "An error occurred while creating the table pedometersensor.\n";
            exit;
        }
        else
        {
            echo "Table pedometersensor created succesfully!\n";
        }

        //-------------------------------------------------------------------------------------------------------------

        $query = "drop table users_tmp,coordinatesf_tmp,sensorsf_tmp;";   

        $result = pg_query($conn, $query);

        if (!$result) {
            echo "An error occurred while dropping the temp tables.\n";
            exit;
        }
        else
        {
            echo "Temp tables deleted succesfully!\n";
        }

        pg_close($conn);
    ?>
</body>

    <?php
        clearstatcache();
    ?>
    
</html>