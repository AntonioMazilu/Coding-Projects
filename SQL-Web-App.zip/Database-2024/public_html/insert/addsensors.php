<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>db1u01 Website</title>
        <link rel="stylesheet" href="../style.css">

    </head>

    <body>

    <div class="navbar">
            <nav>
                <ul>
                    <li> <a class="active" href="http://hilon.dit.uop.gr/~db1u01/">Αρχική</a></li>

                    <li id = "menu"> <a href="#">Εισαγωγή Στοιχείου</a>
                        <ul id = "sub_menu">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu2"> <a href="#">Διαγραφή Στοιχείου</a>
                        <ul id = "sub_menu2">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deleteusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deletesensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu3"> <a href="#">Εμφάνιση Στοιχείων</a>
                        <ul id = "sub_menu3">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu4"> <a href="#">Εισαγωγή Αρχείου</a>
                        <ul id = "sub_menu4">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/addallfiles.php">allfiles</a></li>
                        </ul>
                    </li>
                    <li id = "menu5"> <a href="#">Διαγραφή και Επαναφορά Πίνακα</a>
                        <ul id = "sub_menu5">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetall.php">reset all</a></li>
                        </ul>
                    </li>
                    <li id = "menu6"> <a href="#">Ερωτήματα 3ου Παραδοτέου</a>
                        <ul id = "sub_menu6">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q1.php">Ερώτημα 1</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q2.php">Ερώτημα 2</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q3.php">Ερώτημα 3</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q4.php">Ερώτημα 4</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q5.php">Ερώτημα 5</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q6.php">Ερώτημα 6</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q7.php">Ερώτημα 7</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q8.php">Ερώτημα 8</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q9.php">Ερώτημα 9</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q10.php">Ερώτημα 10</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q11.php">Ερώτημα 11</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q12.php">Ερώτημα 12</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q13.php">Ερώτημα 13</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>
        <h3><u>Εισαγωγή Αισθητήρων</u></h3>
        
        <form action = "<?php echo $_SERVER['PHP_SELF']; ?>" method = "POST">
            <?php
                $conn = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");
                
                $result = pg_query($conn, "SELECT uid FROM users;");
                
                if (!$result) {
                    echo "An error occurred.\n";
                    exit;
                }
                $users = pg_fetch_all($result);

                if ($users) {
                    echo '<label for="userSelect">Επιλογή Χρήστη</label><br>';
                    echo '<select name="uid" id="userSelect" onchange="updateUID()">';
                    foreach ($users as $user) {
                        echo '<option value="'.$user['uid'].'">'.$user['uid'].'</option>';
                    }
                    echo '</select><br>';
                } else {
                    echo 'No users existing.';
                }
            ?>
            <br>
            <label for="uid">UID:</label>
            <input type="text" id="uid" name="uid" required>
            <br>
            <label for="timestamp">Timestamp:</label>
            <input type="date" id="timestamp" name="timestamp" required>
            <br>
            <label for="latitude">Latitude</label>
            <input type="number" id="latitude" name="latitude" required>
            <br>
            <label for="longitude">Longitude</label>
            <input type="number" id="longitude" name="longitude" required>
            <br>
            <label for="altitude">Altitude</label>
            <input type="number" id="altitude" name="altitude" required>
            <br>
            <label for="pressure">Pressure</label>
            <input type="number" id="pressure" name="pressure" required>
            <br>
            <label for="acceleration_x">Acceleration X</label>
            <input type="number" id="acceleration_x" name="acceleration_x" required>
            <br>
            <label for="acceleration_y">Acceleration Y</label>
            <input type="number" id="acceleration_y" name="acceleration_y" required>
            <br>
            <label for="acceleration_z">Acceleration Z</label>
            <input type="number" id="acceleration_z" name="acceleration_z" required>
            <br>
            <label for="gyroscope_x">Gyroscope X</label>
            <input type="number" id="gyroscope_x" name="gyroscope_x" required>
            <br>
            <label for="gyroscope_y">Gyroscope Y</label>
            <input type="number" id="gyroscope_y" name="gyroscope_y" required>
            <br>
            <label for="gyroscope_z">Gyroscope Z</label>
            <input type="number" id="gyroscope_z" name="gyroscope_z" required>
            <br>
            <label for="magnetometer_x">Magnetometer X</label>
            <input type="number" id="magnetometer_x" name="magnetometer_x" required>
            <br>
            <label for="magnetometer_y">Magnetometer Y</label>
            <input type="number" id="magnetometer_y" name="magnetometer_y" required>
            <br>
            <label for="magnetometer_z">Magnetometer Z</label>
            <input type="number" id="magnetometer_z" name="magnetometer_z" required>
            <br>
            <label for="proximity">Proximity</label>
            <input type="checkbox" id="proximity" name="proximity" value="1">
            <br>
            <label for="steps">Steps</label>
            <input type="number" id="steps" name="steps" required>
            <br>
            <br>
            <input type="submit" value="Υποβολή" name="submit" required>
            <br>
        </form>
        <script>
            function updateUID() {
                var select = document.getElementById('userSelect');
                var uidInput = document.getElementById('uid');
                uidInput.value = select.value;
            }
        </script>
            <?php
                if (isset($_POST["submit"])) {
                    error_reporting(0);
                    $uid = pg_escape_string($_POST['uid']);
                    $timestamp = pg_escape_string($_POST['timestamp']);
                    $timestamp2 = strtotime($timestamp);
                    $pressure = pg_escape_string($_POST['pressure']);
                    $acceleration_x = pg_escape_string($_POST['acceleration_x']);
                    $acceleration_y = pg_escape_string($_POST['acceleration_y']);
                    $acceleration_z = pg_escape_string($_POST['acceleration_z']);
                    $gyroscope_x = pg_escape_string($_POST['gyroscope_x']);
                    $gyroscope_y = pg_escape_string($_POST['gyroscope_y']);
                    $gyroscope_z = pg_escape_string($_POST['gyroscope_z']);
                    $magnetometer_x = pg_escape_string($_POST['magnetometer_x']);
                    $magnetometer_y = pg_escape_string($_POST['magnetometer_y']);
                    $magnetometer_z = pg_escape_string($_POST['magnetometer_z']);
                    $proximity = isset($_POST['proximity']) ? 't' : 'f';
                    $steps = pg_escape_string($_POST['steps']);
                    $latitude = pg_escape_string($_POST['latitude']);
                    $longitude = pg_escape_string($_POST['longitude']);
                    $altitude = pg_escape_string($_POST['altitude']);

                    if ($uid && $timestamp && $pressure && $acceleration_x && $acceleration_y && $acceleration_z && $gyroscope_x && $gyroscope_y && $gyroscope_z && $magnetometer_x && $magnetometer_y && $magnetometer_z && $steps && $latitude && $longitude && $altitude) {

                        $conn = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");

                        // Prepare the statement
                        $stmt_check = pg_prepare($conn, "check_element", "SELECT * FROM accelerationsensor, magnetometersensor, gyroscopesensor, barometersensor, proximitysensor, pedometersensor, geolocationsensor  WHERE uid = $1");

                        // Execute the statement
                        $result_check = pg_execute($conn, "check_element", array($uid));

                        echo '<br>';

                        if (pg_num_rows($result_check) == 0) {
                            // Prepare the statements
                            $stmt_insert_acceleration = pg_prepare($conn, "insert_acceleration", "INSERT INTO accelerationsensor (uid, timestamp, acceleration_x, acceleration_y, acceleration_z) VALUES ($1, $2, $3, $4, $5)");

                            $stmt_insert_magnetometer = pg_prepare($conn, "insert_magnetometer", "INSERT INTO magnetometersensor (uid, timestamp, magnetometer_x, magnetometer_y, magnetometer_z) VALUES ($1, $2, $3, $4, $5)");

                            $stmt_insert_gyroscope = pg_prepare($conn, "insert_gyroscope", "INSERT INTO gyroscopesensor (uid, timestamp, gyroscope_x, gyroscope_y, gyroscope_z) VALUES ($1, $2, $3, $4, $5)");

                            $stmt_insert_barometer = pg_prepare($conn, "insert_barometer", "INSERT INTO barometersensor (uid, timestamp, pressure) VALUES ($1, $2, $3)");

                            $stmt_insert_proximity = pg_prepare($conn, "insert_proximity", "INSERT INTO proximitysensor (uid, timestamp, proximity) VALUES ($1, $2, $3)");

                            $stmt_insert_pedometer = pg_prepare($conn, "insert_pedometer", "INSERT INTO pedometersensor (uid, timestamp, steps) VALUES ($1, $2, $3)");

                            $stmt_insert_geolocation = pg_prepare($conn, "insert_geolocation", "INSERT INTO geolocationsensor (uid, timestamp, longitude, latitude, altitude) VALUES ($1, $2, $3, $4, $5)");

                            // Execute the statements
                            pg_execute($conn, "insert_acceleration", array($uid, $timestamp2, $acceleration_x, $acceleration_y, $acceleration_z)) or die("Could not execute query acceleration!\n");

                            pg_execute($conn, "insert_magnetometer", array($uid, $timestamp2, $magnetometer_x, $magnetometer_y, $magnetometer_z)) or die("Could not execute query magnetometer!\n");

                            pg_execute($conn, "insert_gyroscope", array($uid, $timestamp2, $gyroscope_x, $gyroscope_y, $gyroscope_z)) or die("Could not execute query gyroscope!\n");

                            pg_execute($conn, "insert_barometer", array($uid, $timestamp2, $pressure)) or die("Could not execute query barometer!\n");

                            pg_execute($conn, "insert_proximity", array($uid, $timestamp2, $proximity)) or die("Could not execute query proximity!\n");

                            pg_execute($conn, "insert_pedometer", array($uid, $timestamp2, $steps)) or die("Could not execute query pedometer!\n");

                            pg_execute($conn, "insert_geolocation", array($uid, $timestamp2, $longitude, $latitude, $altitude)) or die("Could not execute query geolocation!\n");

                            echo "Data added successfully!\n";
                        } else {
                            echo "Data for UID already exists!\n";
                        }

                        // Close the database connection
                        pg_close($conn);
                    }
                }
            ?>
    </body>

    <?php
        clearstatcache();
    ?>
    
</html>