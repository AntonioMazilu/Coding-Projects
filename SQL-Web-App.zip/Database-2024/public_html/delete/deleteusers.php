<!DOCTYPE html>
<html lang="en">

    <head>

        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>db1u01 Website</title>
        <link rel="stylesheet" href="../style.css">

    </head>

    <body>

    <div class="navbar">
            <nav>
                <ul>
                    <li> <a class="active" href="http://hilon.dit.uop.gr/~db1u01/">Αρχική</a></li>

                    <li id = "menu"> <a href="#">Εισαγωγή Στοιχείου</a>
                        <ul id = "sub_menu">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/insert/addsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu2"> <a href="#">Διαγραφή Στοιχείου</a>
                        <ul id = "sub_menu2">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deleteusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/delete/deletesensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu3"> <a href="#">Εμφάνιση Στοιχείων</a>
                        <ul id = "sub_menu3">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showusers.php">Χρηστων</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/show/showsensors.php">Αισθητηρων</a></li>
                        </ul>
                    </li>
                    <li id = "menu4"> <a href="#">Εισαγωγή Αρχείου</a>
                        <ul id = "sub_menu4">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/addfile/addallfiles.php">allfiles</a></li>
                        </ul>
                    </li>
                    <li id = "menu5"> <a href="#">Διαγραφή και Επαναφορά Πίνακα</a>
                        <ul id = "sub_menu5">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/reset/resetall.php">reset all</a></li>
                        </ul>
                    </li>
                    <li id = "menu6"> <a href="#">Ερωτήματα 3ου Παραδοτέου</a>
                        <ul id = "sub_menu6">
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q1.php">Ερώτημα 1</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q2.php">Ερώτημα 2</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q3.php">Ερώτημα 3</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q4.php">Ερώτημα 4</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q5.php">Ερώτημα 5</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q6.php">Ερώτημα 6</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q7.php">Ερώτημα 7</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q8.php">Ερώτημα 8</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q9.php">Ερώτημα 9</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q10.php">Ερώτημα 10</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q11.php">Ερώτημα 11</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q12.php">Ερώτημα 12</a></li>
                            <li><a href="http://hilon.dit.uop.gr/~db1u01/queries/q13.php">Ερώτημα 13</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>
        </div>

        <h3><u>Διαγραφή Χρήστη</u></h3>
        
        <form action="<?php echo $_SERVER['PHP_SELF']; ?>" method="POST">
            <br>
            <label for="uid">Uid</label><br>
            <select id="uid" name="uid" required>
            <?php
                $conn = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");
                $query = "SELECT uid FROM users";
                $result = pg_query($conn, $query);

                while ($row = pg_fetch_assoc($result)) {
                    echo '<option value="' . $row['uid'] . '">' . $row['uid'] . '</option>';
                }

                pg_close($conn);
            ?>
            </select>
            <br>
            <input type="submit" value="Υποβολή" name="Υποβολή" required>
            <br>
        </form>

        <?php
        if (isset($_POST["Υποβολή"])) 
        {
            error_reporting(0);
            $uid = pg_escape_string($_POST['uid']);

            if ($uid) {
                $conn = pg_connect("host=localhost dbname=db1u01 user=db1u01 password=kvdKXMKF") or die("Could not connect to server\n");

                // Prepare the statement to delete from users
                
                // Prepare the statement to delete from sensors tables
                $sensor_tables = [
                    'geolocationsensor', 'accelerationsensor', 'magnetometersensor', 
                    'gyroscopesensor', 'barometersensor', 'proximitysensor', 'pedometersensor'
                ];
                
                // Execute DELETE statement for each sensor table
                foreach ($sensor_tables as $table) {
                    $result = pg_query_params($conn, "DELETE FROM $table WHERE uid = $1", array($uid));
                
                    if ($result === false) {
                        // Handle error in statement execution
                        die("Error deleting from $table: " . pg_last_error($conn));
                    }
                }
                
                // Prepare and execute the statement to delete from users
                $stmt_user = pg_prepare($conn, "delete_user", "DELETE FROM users WHERE uid = $1");
                $result_user = pg_execute($conn, "delete_user", array($uid));
                
                if ($result_user === false) {
                    // Handle error in statement execution
                    die("Error deleting from users: " . pg_last_error($conn));
                }
                
                // Success
                echo "Deletion successful.";

                // Close the database connection
                pg_close($conn);
            }
        }
        ?>
    </body>

    <?php
        clearstatcache();
    ?>
    
</html>