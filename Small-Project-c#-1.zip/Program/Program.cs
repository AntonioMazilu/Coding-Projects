﻿using System;
using System.Collections.Generic;
using System.Text;
using System.Threading;
using System.Timers;

public class Robot
{
    private int x;
    private int y;
    private int batteryLevel;
    private System.Timers.Timer batteryTimer;

    public delegate void RobotAction();
    public event RobotAction BatteryLow;

    public string Name { get; set; }
    public int BatteryLevel
    {
        get => batteryLevel;
        set
        {
            batteryLevel = value;
            if (batteryLevel < 10)
            {
                BatteryLow?.Invoke();
            }
        }
    }

    private string head;
    private string armsDown;
    private string armsUp;
    private string legs;
    private string legsOpen;

    public Robot(int x, int y)
    {
        this.x = x;
        this.y = y;
        BatteryLevel = 100;
        batteryTimer = new System.Timers.Timer(10000);
        batteryTimer.Elapsed += OnBatteryTimerElapsed;
        batteryTimer.Start();
    }

    private void OnBatteryTimerElapsed(object sender, ElapsedEventArgs e)
    {
        BatteryLevel -= 1;
    }

    public void SetPart(string partName, string partArt)
    {
        switch (partName.ToLower())
        {
            case "head":
                head = partArt;
                break;
            case "arms down":
                armsDown = partArt;
                break;
            case "arms up":
                armsUp = partArt;
                break;
            case "legs":
                legs = partArt;
                break;
            case "legs open":
                legsOpen = partArt;
                break;
            default:
                Console.WriteLine("Unknown part.");
                break;
        }
    }

    public void DrawHead()
    {
        Console.WriteLine(head ?? "  O  ");
    }

    public void DrawArmsUp()
    {
        Console.WriteLine(armsUp ?? " \\|/ ");
    }

    public void DrawArmsDown()
    {
        Console.WriteLine(armsDown ?? " /|\\ ");
    }

    public void DrawLegs()
    {
        Console.WriteLine(legs ?? " / \\ ");
    }

    public void DrawLegsOpen()
    {
        Console.WriteLine(legsOpen ?? "/   \\");
    }

    public void PrintRobot()
    {
        Console.Clear();
        Console.WriteLine("Robot: " + Name);
        Console.WriteLine("Battery Level: " + BatteryLevel + "%");
        DrawHead();
        DrawArmsDown();
        DrawLegs();
    }

    public void Recharge()
    {
        BatteryLevel = 100;
        Console.WriteLine("Battery recharged to 100%.");
    }

    public void Dance()
    {
        Console.Clear();
        for (int i = 0; i < 10; i++)
        {
            Console.Clear();
            DrawHead();
            DrawArmsUp();
            DrawLegs();
            Console.WriteLine("Battery Level: " + BatteryLevel + "%");
            Thread.Sleep(300);

            Console.Clear();
            DrawHead();
            DrawArmsDown();
            DrawLegsOpen();
            Console.WriteLine("Battery Level: " + BatteryLevel + "%");
            Thread.Sleep(300);
        }
    }

    public void Wave()
    {
        Console.Clear();
        for (int i = 0; i < 5; i++)
        {
            Console.Clear();
            DrawHead();
            DrawArmsUp();
            DrawLegs();
            Console.WriteLine("Battery Level: " + BatteryLevel + "%");
            Thread.Sleep(500);

            Console.Clear();
            DrawHead();
            DrawArmsDown();
            DrawLegs();
            Console.WriteLine("Battery Level: " + BatteryLevel + "%");
            Thread.Sleep(500);
        }
    }

    // Overload the + operator to combine two robots
    public static Robot operator +(Robot r1, Robot r2)
    {
        if (r1 == null || r2 == null)
            throw new ArgumentNullException("Cannot combine null robots.");

        Robot combined = new Robot(r1.x, r1.y)
        {
            Name = $"{r1.Name}-{r2.Name}",
            head = r1.head + "\n" + r2.head,
            armsDown = r1.armsDown + "\n" + r2.armsDown,
            armsUp = r1.armsUp + "\n" + r2.armsUp,
            legs = r1.legs + "\n" + r2.legs,
            legsOpen = r1.legsOpen + "\n" + r2.legsOpen
        };
        return combined;
    }

    // Overload the == operator to check if two robots are identical
    public static bool operator ==(Robot r1, Robot r2)
    {
        if (ReferenceEquals(r1, r2)) return true;
        if (r1 is null || r2 is null) return false;
        return r1.head == r2.head &&
               r1.armsDown == r2.armsDown &&
               r1.armsUp == r2.armsUp &&
               r1.legs == r2.legs &&
               r1.legsOpen == r2.legsOpen;
    }

    public static bool operator !=(Robot r1, Robot r2)
    {
        return !(r1 == r2);
    }

    public override bool Equals(object obj)
    {
        if (obj is Robot robot)
        {
            return this == robot;
        }
        return false;
    }

    public override int GetHashCode()
    {
        return (head, armsDown, armsUp, legs, legsOpen).GetHashCode();
    }
}

class Program
{
    static void Main(string[] args)
    {
        List<Robot> robots = new List<Robot>();

        while (true)
        {
            Console.WriteLine("Menu:");
            Console.WriteLine("1) Create Robot");
            Console.WriteLine("2) Select Robot");
            Console.WriteLine("3) Combine Robots");
            Console.WriteLine("4) Replace Robots");
            Console.WriteLine("5) Exit");

            if (!int.TryParse(Console.ReadLine(), out int menuChoice) || (menuChoice < 1 || menuChoice > 5))
            {
                Console.WriteLine("Invalid choice. Please enter a number between 1 and 5.");
                continue;
            }

            if (menuChoice == 5)
                break;

            if (menuChoice == 1 && robots.Count < 2)
            {
                Console.WriteLine($"Enter the name for robot {robots.Count + 1}:");
                string name = Console.ReadLine();
                Robot robot = new Robot(0, 0) { Name = name };
                robot.BatteryLow += () => Console.WriteLine($"{name}'s battery is below 10%.");

                Console.WriteLine("Enter ASCII art for the robot's head (end with an empty line):");
                string headArt = ReadMultiLineInput();
                robot.SetPart("head", headArt);

                Console.WriteLine("Enter ASCII art for the robot's arms down (end with an empty line):");
                string armsDownArt = ReadMultiLineInput();
                robot.SetPart("arms down", armsDownArt);

                Console.WriteLine("Enter ASCII art for the robot's arms up (end with an empty line):");
                string armsUpArt = ReadMultiLineInput();
                robot.SetPart("arms up", armsUpArt);

                Console.WriteLine("Enter ASCII art for the robot's legs (end with an empty line):");
                string legsArt = ReadMultiLineInput();
                robot.SetPart("legs", legsArt);

                Console.WriteLine("Enter ASCII art for the robot's legs open (end with an empty line):");
                string legsOpenArt = ReadMultiLineInput();
                robot.SetPart("legs open", legsOpenArt);

                robots.Add(robot);
                Console.WriteLine($"Robot {name} created:");
                robot.PrintRobot();
            }
            else if (menuChoice == 2)
            {
                Console.WriteLine("Enter the name of the robot you want to use:");
                string name = Console.ReadLine();
                Robot robot = robots.Find(r => r.Name == name);
                if (robot == null)
                {
                    Console.WriteLine("Robot not found.");
                    continue;
                }

                while (true)
                {
                    Console.WriteLine("Choose an action: 1) Dance 2) Wave 3) Recharge 4) Print Robot 5) Exit to Main Menu");
                    if (!int.TryParse(Console.ReadLine(), out int choice) || (choice < 1 || choice > 5))
                    {
                        Console.WriteLine("Invalid choice. Please enter a number between 1 and 5.");
                        continue;
                    }

                    if (choice == 5)
                        break;

                    switch (choice)
                    {
                        case 1:
                            robot.Dance();
                            break;
                        case 2:
                            robot.Wave();
                            break;
                        case 3:
                            robot.Recharge();
                            break;
                        case 4:
                            robot.PrintRobot();
                            break;
                        default:
                            Console.WriteLine("Invalid choice.");
                            break;
                    }

                    if (robot.BatteryLevel < 10)
                    {
                        Console.WriteLine("Do you want to recharge the robot? (yes/no)");
                        string recharge = Console.ReadLine().ToLower();
                        if (recharge == "yes")
                        {
                            robot.Recharge();
                        }
                        else if (robot.BatteryLevel == 0)
                        {
                            Console.WriteLine("Battery is empty. Please choose another robot.");
                            break;
                        }
                    }
                }
            }
            else if (menuChoice == 3)
            {
                if (robots.Count < 2)
                {
                    Console.WriteLine("You need at least two robots to combine.");
                    continue;
                }

                Console.WriteLine("Enter the name of the first robot:");
                string name1 = Console.ReadLine();
                Robot robot1 = robots.Find(r => r.Name == name1);

                Console.WriteLine("Enter the name of the second robot:");
                string name2 = Console.ReadLine();
                Robot robot2 = robots.Find(r => r.Name == name2);

                if (robot1 == null || robot2 == null)
                {
                    Console.WriteLine("One or both robots not found.");
                    continue;
                }

                Robot combinedRobot = robot1 + robot2;
                Console.WriteLine("Combined Robot:");
                combinedRobot.PrintRobot();
                robots.Add(combinedRobot);
            }
            else if (menuChoice == 4)
            {
                if (robots.Count < 2)
                {
                    Console.WriteLine("You need at least two robots to replace.");
                    continue;
                }

                Console.WriteLine("Enter the name of the robot to be replaced:");
                string nameToReplace = Console.ReadLine();
                Robot robotToReplace = robots.Find(r => r.Name == nameToReplace);

                Console.WriteLine("Enter the name of the robot to replace with:");
                string nameToReplaceWith = Console.ReadLine();
                Robot robotToReplaceWith = robots.Find(r => r.Name == nameToReplaceWith);

                if (robotToReplace == null || robotToReplaceWith == null)
                {
                    Console.WriteLine("One or both robots not found.");
                    continue;
                }

                robots.Remove(robotToReplace);
                robots.Add(robotToReplaceWith);

                Console.WriteLine($"{nameToReplace} has been replaced with {nameToReplaceWith}.");
                robotToReplaceWith.PrintRobot();
            }
            else
            {
                Console.WriteLine("Invalid choice.");
            }
        }
    }

    static string ReadMultiLineInput()
    {
        StringBuilder sb = new StringBuilder();
        string line;
        while (!string.IsNullOrEmpty(line = Console.ReadLine()))
        {
            sb.AppendLine(line);
        }
        return sb.ToString().TrimEnd();
    }
}