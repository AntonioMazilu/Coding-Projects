# Information_Retrieval

## Steps to initialize the app

- pip -r install requirements.txt

## Steps to start the app

- python3 app.py
- navigate to http://127.0.0.1:5000/