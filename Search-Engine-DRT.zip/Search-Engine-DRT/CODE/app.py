from flask import Flask, render_template, request, redirect, url_for, flash
from elasticsearch import Elasticsearch, NotFoundError
import os
import secrets
import pandas as pd
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Initialize Flask app
app = Flask(__name__)
app.secret_key = secrets.token_hex(24)

# Elasticsearch setup
ELASTICSEARCH_URL = os.getenv("ELASTICSEARCH_URL")
API_KEY = os.getenv("ELASTICSEARCH_API_KEY")

es = Elasticsearch(
    ELASTICSEARCH_URL,
    api_key=API_KEY,
)

INDEX_NAME = "offender_record"

# Ensure the index is created with proper mappings
def create_index():
    mapping = {
        "settings": {
            "analysis": {
                "char_filter": {
                    "remove_invalid_characters": {
                        "type": "pattern_replace",
                        "pattern": "ÿ",
                        "replacement": ""
                    }
                },
                "analyzer": {
                    "casefolding_analyzer": {
                        "type": "custom",
                        "tokenizer": "standard",
                        "char_filter": ["remove_invalid_characters"],
                        "filter": ["lowercase", "stop", "porter_stem"]
                    }
                }
            }
        },
        "mappings": {
            "properties": {
                "Age": {"type": "long"},
                "AgeWhenReceived": {"type": "keyword"},
                "BlackVictim": {"type": "keyword"},
                "Codefendants": {"type": "keyword"},
                "CountyOfConviction": {"type": "keyword"},
                "EducationLevel": {"type": "keyword"},
                "Execution": {"type": "long"},
                "FemaleVictim": {"type": "keyword"},
                "FirstName": {
                    "type": "text",
                    "analyzer": "casefolding_analyzer"
                },
                "HispanicVictim": {"type": "keyword"},
                "LastName": {
                    "type": "text",
                    "analyzer": "casefolding_analyzer"
                },
                "LastStatement": {
                    "type": "text",
                    "analyzer": "casefolding_analyzer"
                },
                "MaleVictim": {"type": "keyword"},
                "NativeCounty ": {"type": "keyword"},
                "NumberVictim": {"type": "keyword"},
                "PreviousCrime": {"type": "keyword"},
                "Race": {"type": "keyword"},
                "TDCJNumber": {"type": "long"},
                "VictimOther Races": {"type": "keyword"},
                "WhiteVictim": {"type": "keyword"}
            }
        }
    }

    try:
        if not es.indices.exists(index=INDEX_NAME):
            es.indices.create(index=INDEX_NAME, body=mapping)
            print(f"Created index: {INDEX_NAME}")
        else:
            print(f"Index already exists: {INDEX_NAME}")
    except Exception as e:
        print(f"Error creating index: {e}")

# Initialize the index on startup
create_index()

#Home app
@app.route("/")
def index():
    return render_template("index.html")

# Add a single record to Elasticsearch
def add_record(record):
    try:
        response = es.index(index=INDEX_NAME, document=record)
        print(f"Document added with ID: {response['_id']}")
    except Exception as e:
        print(f"Error adding record: {e}")

@app.route("/add", methods=["GET", "POST"])
def add():
    if request.method == "POST":
        # Parse form data and ensure it matches Elasticsearch mappings
        try:
            record = {
                "Age": int(request.form.get("age", 0)),  # long
                "AgeWhenReceived": request.form.get("age_received", "").strip(),  # keyword
                "BlackVictim": request.form.get("black_victim", "").strip(),  # keyword
                "Codefendants": request.form.get("codefendants", "").strip(),  # keyword
                "CountyOfConviction": request.form.get("county", "").strip(),  # keyword
                "EducationLevel": request.form.get("education", "").strip(),  # keyword
                "Execution": int(request.form.get("execution", 0)),  # long
                "FemaleVictim": request.form.get("female_victim", "").strip(),  # keyword
                "FirstName": request.form.get("firstname", "").strip(),  # keyword
                "HispanicVictim": request.form.get("hispanic_victim", "").strip(),  # keyword
                "LastName": request.form.get("lastname", "").strip(),  # keyword
                "LastStatement": request.form.get("last_statement", "").strip(),  # text
                "MaleVictim": request.form.get("male_victim", "").strip(),  # keyword
                "NativeCounty ": request.form.get("native_county", "").strip(),  # keyword
                "NumberVictim": request.form.get("number_victim", "").strip(),  # keyword
                "PreviousCrime": request.form.get("previous_crime", "").strip(),  # keyword
                "Race": request.form.get("race", "").strip(),  # keyword
                "TDCJNumber": int(request.form.get("tdcjnumber", 0)),  # long
                "VictimOther Races": request.form.get("victim_other_races", "").strip(),  # keyword
                "WhiteVictim": request.form.get("white_victim", "").strip()  # keyword
            }
            # Add record to Elasticsearch
            add_record(record)
            flash("Record added successfully to Elasticsearch.", "success")
            return redirect(url_for("index"))

        except ValueError as ve:
            flash(f"Invalid input: {ve}", "danger")
        except Exception as e:
            flash(f"An error occurred: {e}", "danger")

    # Render the form for adding a record
    return render_template("add_record.html")


@app.route('/delete/<doc_id>', methods=['POST'])
def delete_document(doc_id):
    try:
        # Delete the document from Elasticsearch using the document ID
        es.delete(index=INDEX_NAME, id=doc_id)
        # Redirect to a confirmation page or back to the search results
        return redirect(url_for('index', message="Document deleted successfully"))
    except NotFoundError:
        return redirect(url_for('index', message="Document not found"))
    except Exception as e:
        return redirect(url_for('index', message=f"Error: {str(e)}"))
    
@app.route('/delete_multiple_documents', methods=['POST'])
def delete_multiple_documents():
    # Get the selected document IDs from the form
    selected_ids = request.form.getlist('selected_ids')
    
    if not selected_ids:
        # Flash a danger message if no documents are selected
        flash('No documents selected for deletion.', 'danger')
        return redirect(url_for('index'))

    # Prepare the bulk delete actions for Elasticsearch
    actions = [
        {"delete": {"_index": INDEX_NAME, "_id": doc_id}}
        for doc_id in selected_ids
    ]
    
    try:
        # Execute the bulk delete operation
        response = es.bulk(body=actions)
        
        # Check if there were errors during deletion
        if response['errors']:
            # Flash a danger message in case of errors
            flash('Error occurred during deletion.', 'danger')
        else:
            # Flash a success message if deletion is successful
            flash(f'{len(selected_ids)} document(s) deleted successfully.', 'success')
    except Exception as e:
        # Flash a danger message in case of exception
        flash(f'Error: {str(e)}', 'danger')

    return redirect(url_for('index'))


# Bulk upload records from CSV to Elasticsearch (No batching)
def bulk_upload_csv(file_path):
    try:
        # Try reading the CSV with different encodings
        try:
            df = pd.read_csv(
                file_path,
                na_values=["NA", "N/A", "null"],
                encoding='utf-8'  # Default encoding
            )
        except UnicodeDecodeError:
            print(f"Failed to decode with UTF-8. Trying 'ISO-8859-1'.")
            df = pd.read_csv(
                file_path,
                na_values=["NA", "N/A", "null"],
                encoding='ISO-8859-1'  # Fallback to a different encoding
            )

        # Check if the required columns are in the CSV headers
        expected_columns = [
            "Execution", "LastName", "FirstName", "TDCJNumber", "Age", "Race", 
            "CountyOfConviction", "AgeWhenReceived", "EducationLevel", "NativeCounty ",
            "PreviousCrime", "Codefendants", "NumberVictim", "WhiteVictim", "HispanicVictim",
            "BlackVictim", "VictimOther Races", "FemaleVictim", "MaleVictim", "LastStatement"
        ]
        
        # Ensure that the CSV file contains the expected columns
        for col in expected_columns:
            if col not in df.columns:
                raise ValueError(f"Missing column in CSV: {col}")

        # Fill missing values with defaults (if needed)
        df = df.fillna({
            "Execution": 0,
            "LastName": "",
            "FirstName": "",
            "TDCJNumber": 0,
            "Age": 0,
            "Race": "",
            "CountyOfConviction": "",
            "AgeWhenReceived": "",
            "EducationLevel": "",
            "NativeCounty ": "",
            "PreviousCrime": "",
            "Codefendants": "",
            "NumberVictim": "",
            "WhiteVictim": "",
            "HispanicVictim": "",
            "BlackVictim": "",
            "VictimOther Races": "",
            "FemaleVictim": "",
            "MaleVictim": "",
            "LastStatement": ""
        })

        # Prepare actions for bulk upload
        actions = []
        for _, row in df.iterrows():
            try:
                record = {
                    "Execution": int(row["Execution"]),
                    "LastName": row["LastName"],
                    "FirstName": row["FirstName"],
                    "TDCJNumber": int(row["TDCJNumber"]),
                    "Age": int(row["Age"]),
                    "Race": row["Race"],
                    "CountyOfConviction": row["CountyOfConviction"],
                    "AgeWhenReceived": row["AgeWhenReceived"],
                    "EducationLevel": row["EducationLevel"],
                    "NativeCounty ": row["NativeCounty "],
                    "PreviousCrime": row["PreviousCrime"],
                    "Codefendants": row["Codefendants"],
                    "NumberVictim": row["NumberVictim"],
                    "WhiteVictim": row["WhiteVictim"],
                    "HispanicVictim": row["HispanicVictim"],
                    "BlackVictim": row["BlackVictim"],
                    "VictimOther Races": row["VictimOther Races"],
                    "FemaleVictim": row["FemaleVictim"],
                    "MaleVictim": row["MaleVictim"],
                    "LastStatement": row["LastStatement"]
                }
                actions.append({"index": {"_index": INDEX_NAME}})
                actions.append(record)
            except Exception as row_error:
                print(f"Error processing row {row}: {row_error}")

        # Bulk insert all the records at once
        if actions:
            try:
                response = es.bulk(body=actions)
                if response.get("errors"):
                    print(f"Error during bulk upload: {response}")
                else:
                    print(f"Successfully uploaded the CSV.")
            except Exception as batch_error:
                print(f"Error uploading CSV: {batch_error}")

    except Exception as e:
        print(f"Error during bulk upload: {e}")


@app.route("/upload", methods=["GET", "POST"])
def upload():
    if request.method == "POST":
        file = request.files.get("file")
        if not file or not file.filename.endswith(".csv"):
            flash("Invalid file. Please upload a CSV file.", "danger")
            return redirect(request.url)

        upload_folder = "uploads"
        os.makedirs(upload_folder, exist_ok=True)

        file_path = os.path.join(upload_folder, file.filename)
        file.save(file_path)

        try:
            bulk_upload_csv(file_path)
            flash("CSV uploaded and processed successfully.", "success")
        except Exception as e:
            flash(f"Error processing CSV: {e}", "danger")

        return redirect(url_for("index"))

    return render_template("upload.html")


@app.route("/search", methods=["GET", "POST"])
def search():
    print("\n=== Starting Search Route ===")
    results = []
    selected_fields = []
    
    if request.method == "POST":
        print("\nPOST request received")
        print("Form data:", request.form)
        
        # Retrieve user inputs
        query = request.form.get("query")
        print(f"Query: '{query}'")
        
        not_query = request.form.get("not_query")
        print(f"Not Query: '{not_query}'")
        
        boolean_operator = request.form.get("boolean_operator", "AND")
        print(f"Boolean Operator: {boolean_operator}")
        
        try:
            top_k = int(request.form.get("top_k", 10))
            print(f"Top K: {top_k}")
        except ValueError as e:
            print(f"Error parsing top_k: {e}")
            top_k = 10

        # Retrieve selected fields for display
        selected_fields = request.form.getlist("search_fields")
        print(f"Selected Fields: {selected_fields}")

        # Call search_records function
        try:
            # If both query and filters are empty, return an error
            if not query and not selected_fields:
                print("Error: No query or selected fields provided")
                return render_template("search.html", error="Please provide a query or select fields.")

            print("\nExecuting search with parameters:")
            print(f"- Query: {query}")
            print(f"- Boolean Operator: {boolean_operator}")
            print(f"- Not Query: {not_query}")
            print(f"- Top K: {top_k}")
            print(f"- Selected Fields: {selected_fields}")

            response = search_records(
                query=query,
                boolean_operator=boolean_operator,
                not_query=not_query,
                top_k=top_k,
                selected_fields=selected_fields
            )
            
            results = response["hits"]["hits"]
            print(f"\nSearch returned {len(results)} results")
            
            if not results:
                print("Warning: No results found")
            
        except Exception as e:
            print(f"\nError during search: {str(e)}")
            return render_template("search.html", error=f"Search failed: {str(e)}")

    else:
        print("\nGET request received - displaying empty search form")

    print("\n=== Ending Search Route ===")
    return render_template("search.html", results=results, selected_fields=selected_fields)


def search_records(query, boolean_operator="AND", not_query=None, top_k=10, selected_fields=None):
    must_conditions = []
    should_conditions = []
    must_not_conditions = []

    all_fields = [
        "FirstName", "LastName", "LastStatement", "Race", "CountyOfConviction",
        "EducationLevel", "PreviousCrime", "Codefendants", "Age", "AgeWhenReceived",
        "BlackVictim", "CountyOfConviction", "EducationLevel", "Execution",
        "FemaleVictim", "HispanicVictim", "MaleVictim", "NativeCounty", 
        "NumberVictim", "TDCJNumber", "VictimOtherRaces", "WhiteVictim"
    ]

    # Add main query with user-selected Boolean operator handling
    if query:
        terms = query.split()
        if boolean_operator == "AND":
            must_conditions.extend([
                {"multi_match": {
                    "query": term,
                    "fields": selected_fields or all_fields,
                    "type": "best_fields"
                }} for term in terms
            ])
        elif boolean_operator == "OR":
            should_conditions.extend([
                {"multi_match": {
                    "query": term,
                    "fields": selected_fields or all_fields,
                    "type": "best_fields"
                }} for term in terms
            ])

    # Add NOT conditions
    if not_query:
        must_not_conditions.append({
            "multi_match": {
                "query": not_query,
                "fields": selected_fields or all_fields
            }
        })

    # Construct query body
    query_body = {
        "query": {
            "bool": {
                "must": must_conditions if boolean_operator == "AND" else [],
                "should": should_conditions if boolean_operator == "OR" else [],
                "must_not": must_not_conditions,
            }
        },
        "size": top_k,
        "highlight": {
            "fields": {
                "LastStatement": {"fragment_size": 150, "number_of_fragments": 1}
            }
        }
    }

    query_body["_source"] = True

    try:
        return es.search(index=INDEX_NAME, body=query_body)
    except Exception as e:
        print(f"Error in Elasticsearch query: {e}")
        return {"hits": {"hits": []}}

if __name__ == "__main__":
    app.run(debug=True)