import pandas as pd
import numpy as np
import networkx as nx
import matplotlib.pyplot as plt
import os

# Define the file path
file_path = r"C:\Users\anton\Documents\Project 2\marvel.csv"

# Check if file exists
if not os.path.exists(file_path):
    print(f"File not found: {file_path}")
    exit()

# Load the dataset
df = pd.read_csv(file_path, header=None, names=["Hero", "Comic"])

# Create a set of all heroes
heroes = sorted(df["Hero"].unique())
hero_index = {hero: i for i, hero in enumerate(heroes)}

# Create an adjacency matrix
N = len(heroes)
adj_matrix = np.zeros((N, N))

# Populate the adjacency matrix based on shared comic appearances
for comic, group in df.groupby("Comic"):
    hero_list = list(group["Hero"])
    for i in range(len(hero_list)):
        for j in range(i + 1, len(hero_list)):
            idx1, idx2 = hero_index[hero_list[i]], hero_index[hero_list[j]]
            adj_matrix[idx1, idx2] += 1
            adj_matrix[idx2, idx1] += 1  # Since the graph is undirected

# Normalize the adjacency matrix
row_sums = adj_matrix.sum(axis=1, keepdims=True)
transition_matrix = np.divide(adj_matrix, row_sums, where=row_sums != 0)

# PageRank parameters
alpha = 0.85  # Damping factor
tolerance = 1e-6  # Convergence threshold
max_iterations = 100  # Max iterations

# Initialize PageRank scores
pagerank = np.ones(N) / N

# Iterative Power Method for PageRank
for iteration in range(max_iterations):
    new_pagerank = (1 - alpha) / N + alpha * transition_matrix.T @ pagerank
    
    # Check convergence (difference between iterations)
    if np.linalg.norm(new_pagerank - pagerank, ord=1) < tolerance:
        print(f"Converged after {iteration+1} iterations")
        break
    
    pagerank = new_pagerank

# Rank heroes by PageRank score
hero_ranking = sorted(zip(heroes, pagerank), key=lambda x: x[1], reverse=True)[:10]

# Display top 10 heroes
print("\nTop 10 Heroes by PageRank:")
for hero, score in hero_ranking:
    print(f"{hero}: {score:.6f}")

# Graph visualization
try:
    print("Creating graph visualization...")
    G = nx.Graph()
    G.add_edges_from([(heroes[i], heroes[j]) for i in range(N) for j in range(N) if adj_matrix[i, j] > 0])
    print("Graph created.")

    plt.figure(figsize=(12, 12))
    pos = nx.spring_layout(G, k=0.15)
    nx.draw(G, pos, with_labels=True, node_size=50, font_size=8)
    plt.title("Marvel Heroes Graph")
    print("Graph drawn.")

    # Save the plot as a PNG file
    output_path = r"C:\Users\anton\Documents\Project 2\marvel_heroes_graph.png"
    plt.savefig(output_path)
    print(f"Graph saved as {output_path}")

    # Display the plot
    plt.show()
    print("Graph displayed.")
except Exception as e:
    print(f"An error occurred: {e}")